<?php
    //cabecalho.php
    echo '<head><link rel="stylesheet" type="text/css" 
    href="css/main.css"></head>';

    echo '<div class="corpo_forum">'; //abertura do corpo do forum

    echo '<img src="image/logo.png"><br><hr>'; //logotipo do forum

?>