<?php
    //rodape.php

    echo '</div>'; //Fecho do corpo do forum (aberto no cabeçalho)

    echo '<div class="rodape">Webmaster: &copy; 2023</div>';

?>
